package generation;

public class HelloWord {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		System.out.println("Hello Word");
		System.out.println("O PAI TA ON !");
	}

}
